Continue our research on Diophantine definability of Z in Q
using the attached flat PDF-first handoff bundle, pinned to
d3a8c223716a0fc0dbf5af4eb7998d640c21048d.

First read README.md, research_directions.md, results_20261117_v75.md,
results_20261117_v76.md, results_20261117_v77.md, and
criteria_20261117_v77.json. The v75-v77 records override older summaries.
Read original LaTeX papers as their same-named PDF counterparts.

Priorities:
1. Prove global rational realization and complete the 21-variable general
   and 9-variable ordinary-abc definitions, preserving actual detector
   traces, physical slope/weight relations, every original and whole-character
   guard, and fixed-shift completeness quantifiers.
2. Improve general quartic variable counts with constructions beyond already
   excluded compression architectures.
3. Improve general and abc-conditional constructions, prioritizing variable
   count, then degree, then coefficient heights.
4. Investigate Diophantine definability of integer rings of number fields.

State assumptions precisely. Separate proved, conditional, conjectural and
computational statements. Reconstruct decisive identities and use exact
independent checks. Real/local points do not imply global rational points.
Do not claim 21/9 completeness without an actual global theorem.
