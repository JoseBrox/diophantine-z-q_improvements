# OpenAI API Playground research handoff — flat PDF edition

This ZIP contains **32 selected original repository files**, with each TeX paper
converted to a searchable mathematical PDF, plus these four handoff files:
\`README_START_HERE.md\`, \`PRIORITY_LIST.md\`, \`HANDOFF_PROMPT.md\`,
and \`SOURCE_MANIFEST.json\`.

All files are in the **root of the ZIP**. There are no directories and no
\`.tex\` files. The full 17/15 priority split is in \`PRIORITY_LIST.md\`.

Start with:
1. \`PRIORITY_LIST.md\` and \`HANDOFF_PROMPT.md\`;
2. \`README.md\`, \`research_directions.md\`, and results_v75–v77;
3. the papers and additional source files relevant to the current question.

The source commit is d3a8c223716a0fc0dbf5af4eb7998d640c21048d.
Original source paths and exact blob SHA values, PDF conversion details,
page counts, and SHA-256 checksums are in \`SOURCE_MANIFEST.json\`.

Global rational realization is still open for 21 general / 9 ordinary-abc
variables. Do not confuse sound source equations, local solubility or real
positivity with a proof of completeness.
