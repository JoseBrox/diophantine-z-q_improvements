# Three-detector quartic in 229 coordinates

The complete algebraic construction and its independent check are ready.
An effective arithmetic defining threshold must be supplied separately.

Starting with the certified 195-coordinate system, copy all 34 local
coordinates and 31 rows of the second detector. Replace its aggregate
constant and add one quadratic equation for the conjugate component of
the elliptic abscissa sum. Both components use existing coordinates.
All three complete detector blocks, auxiliary squares and inverse guards
are included in the count.

The resulting family has 229 variables, 207 quadratic squares, 3,312
monomials, degree 4 and content 1. Its exact coefficient height is

```math
\max\{126616122944180358034867798936,149^{2N+2}\}.
```

The fixed parameter is $C=149^N$, with $N\ge1$. The coefficient crossover
at $N=6$ is independent of a sufficient arithmetic defining threshold.

The argument shifts are

```math
t_1-t_0=13+S_0/2,\qquad
t_2-t_1=17+(S_0-S_1)/2,
```

where $S_0+S_1\sqrt2$ is the four-point abscissa sum. They are at least
7 and 9 on the full finite point domain, including torsion points.
This separates all thirty reflected contact forms.

## Verification

Run the independent standard-library checker:

```sh
python -B check.py
```

`build.py` reproduces the family. `check.py` authenticates the source,
checks each row and coordinate map, reconstructs both field components,
checks all guards and the shift identities, expands the quartic by a
different algorithm, and certifies its exact support and coefficient
height for every permitted parameter.

`quartic229.tex` contains the algebraic proof, shift separation and height
identity. `quadratic.json` specifies all equations, `polynomial.json`
specifies all coefficients, and `graft.json` records the exact maps.

No reduction in the general 25-variable or conditional 11-variable
definition is asserted by this package.
