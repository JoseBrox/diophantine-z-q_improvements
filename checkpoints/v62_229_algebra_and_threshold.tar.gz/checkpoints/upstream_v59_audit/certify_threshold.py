#!/usr/bin/env python3
"""Exact elementary certificates for the N >= 6743 arithmetic refinement.

This certifies numerical inequalities and finite contact support only.
It does not certify the inherited geometric five-contact height theorem,
the prime-pattern theorem, or the complete polynomial coordinate maps.
No third-party packages are required.
"""

from fractions import Fraction as F
from math import factorial, isqrt, prod


def exp_lower(x, degree=40):
    return sum((x**j / factorial(j) for j in range(degree + 1)), F(0))


def exp_upper(x, degree=40):
    # Subsequent positive Taylor terms have ratio at most x/(degree+2).
    assert 0 <= x < degree + 2
    return exp_lower(x, degree) + x**(degree + 1) / factorial(degree + 1) / (1 - x / (degree + 2))


limit = 76176
sieve = bytearray(b"\x01") * (limit + 1)
sieve[0] = sieve[1] = 0
for p in range(2, isqrt(limit) + 1):
    if sieve[p]:
        sieve[p * p : limit + 1 : p] = b"\x00" * len(range(p * p, limit + 1, p))
primes = [p for p in range(2, limit + 1) if sieve[p]]
B = prod(primes)
Bplus = prod(p + 1 for p in primes)
S = {2, 3, 5, 7, 11, 13, 17, 37, 41, 2399}
BS = prod(S)
E2 = 2029147
CN = 2**68 * 3**16 * 5**16 * 7**4
c0 = F(74712001, 1000000)
assert len(primes) == 7499 and primes[-1] == 76163
assert B.bit_length() == 109445
assert B < 2**109445
assert Bplus < 16 * B  # E(B) = product (p+1)/p < 16.
assert BS == 1857890364330 and BS < 2**41
assert c0 < 2**7 and CN < 2**142
assert E2 < 2**21
assert all(E2 % p for p in primes if p * p <= E2)

plus = [(1, 0), (2, 1), (1, 1), (-2399, 1), (407, 32)]
minus = [(-1, 2), (-2, 5), (-1, 3), (2399, -4797), (-407, 846)]


def prime_support(n):
    n = abs(n)
    assert n
    support = set()
    for p in primes:
        if p * p > n:
            break
        if n % p == 0:
            support.add(p)
            while n % p == 0:
                n //= p
    if n > 1:
        support.add(n)
    return support


collisions = set()
for a, b in plus:
    for c, d in minus:
        collisions |= prime_support(a * d - b * c)
expected_outside_S = {47, 67, 109, 179, 257, 439, 2099, E2}
assert collisions - S == expected_outside_S
Csmall = prod(expected_outside_S - {E2})
assert Csmall == 14549975824231303 and Csmall < 2**54
assert BS * B * Csmall * E2**2 < 2**109582

# Elementary logarithmic bounds are certified by positive Taylor series.
assert exp_upper(F(5)) < 149 < exp_lower(F(501, 100))
assert exp_lower(F(7, 10)) > 2
assert exp_lower(F(2)) > 7
assert exp_lower(F(7)) > 864
assert exp_lower(F(55, 12)) > 96
assert exp_lower(F(9)) > 676
assert exp_lower(F(3)) > 14
assert F(109582 * 7, 20) + 1 < 38355
assert 38355 < 22 * 2**11
assert F(109445 * 7, 10) < 2**17

N = 6743
L = 9 * (2 * N - 1) // 4 + 1
K_exponent = 109754
assert L == 30342
assert 149**L > 2**219044
assert 149 ** (2 * L) * 100**6 > 300**3 * 2 ** (3 * K_exponent) * (2300 + 334 * L) ** 6
assert 300**3 > 121**3 * 14
assert 484 * 23**2 == 256036 < 2**18
assert F(23 * 7 * (K_exponent + 18), 220) < 120000
assert 5 * L == 151710
assert F(99 * 151709, 100) > 150000
assert (150000 * 11 - 12 * 2**17) * 600 > 120000 * 11
assert 149**L > 600

print("PASS: primorial support, all 25 cross-contact determinants, and E(B*) < 16")
print("PASS: reflected height constant K = 2^109754")
print("PASS: scalar height coefficient 2^219061 and tau < 2^17 c at N=6743")
print("PASS: Delta and Lucas numerical contradictions for every N >= 6743")
print("Scope: inherited height/prime-pattern/coordinate theorems remain explicit premises")
