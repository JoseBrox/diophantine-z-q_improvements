# Effective reflected contact bounds and torsion translates

## Scope

Fix the source `manuscripts/quartic_v19.tex` at upstream commit `498efba6fe75e9d28d6804f1391d7f70e4150afa`. The argument below consumes its full-family five-contact theorem H4.1, the scalar divisibility, and the local detector extraction and Lucas lemma at their stated domains. It independently improves the height consumers. It is not an independent verification of the geometric/modular foundation of H4.1 or of the prime-pattern theorem.

Set

\[
S=\{2,3,5,7,11,13,17,37,41,2399\},\quad B_S=1857890364330,
\]
\[
B_*=\prod_{p\le76176}p,\quad E(R)=\prod_{p\mid R}(1+p^{-1}),
\quad c_0=\frac{74712001}{10^6},\quad C_N=2^{68}3^{16}5^{16}7^4.
\]

The inherited theorem gives, for every admitted rational argument u,

\[
h(u)<c_0C_NR(u)^2E(R(u))\log R(u),\qquad R(u)=B_SM_S(u).
\tag{1}
\]

## Joint reflected radical accounting

Let t=a/b in lowest terms, b>0, and exclude the ten contacts

\[
\Theta_2=\Theta\cup(2-\Theta),\qquad
\Theta=\{0,-1/2,-1,1/2399,-32/407\}.
\]

Put u_+=2+1/t and u_-=2+1/(2-t). Their primitive contact forms are

\[
a,\ 2a+b,\ a+b,\ b-2399a,\ 407a+32b
\]

and

\[
2b-a,\ 5b-2a,\ 3b-a,\ 2399a-4797b,\ 846b-407a.
\]

The primes outside S dividing any cross determinant are exactly

\[
47,67,109,179,257,439,2099,E_2,\qquad E_2=2029147.
\]

This is checked by exact factorization of the 25 determinants. Let

\[
C_{\rm small}=47\cdot67\cdot109\cdot179\cdot257\cdot439\cdot2099
=14549975824231303<2^{54}.
\]

Write M for the odd contact radical of t outside the primes at most 76176 and E2. At a small prime outside S and the cross-collision set, at most one of M_S(u_+) and M_S(u_-) contains that prime: otherwise their two primitive linear forms force both a and b divisible by it. At a cross-collision prime the product can contain its square. At primes in S, the two R factors contribute exactly B_S squared. Above the cutoff, E2 can occur twice, and every other prime contributes exactly the corresponding factor of M. Consequently

\[
R(u_+)R(u_-)\le B_SB_*C_{\rm small}E_2^2M<2^{109582}M.
\tag{2}
\]

This is a pointwise product bound; it does not require either small-prime radical to be fixed, and it applies at arbitrary odd contact depths.

The two inverse height maps give h(u_+),h(u_-)>=h(t)-log7. If h(t)>log7, multiply (1), take square roots, and use E(R)<=1+logR and the arithmetic-geometric mean inequality. With T=R(u_+)R(u_-),

\[
h(t)<\log7+c_0C_NT(1+\tfrac12\log T)\tfrac12\log T.
\]

Since c0<2^7, CN<2^142, log2<7/10, and (2) holds,

\[
h(t)<\log7+2^{109731}M(38355+\tfrac12\log M)^2.
\]

The inequality 38355<22*2^11 and absorption of log7 give the uniform bound

\[
\boxed{h(t)\le K M(22+\tfrac12\log M)^2,\qquad K=2^{109754}.}
\tag{3}
\]

When h(t)<=log7, (3) is immediate. The contact stratum t=1 is included; no division by t-1 occurs.

## Scalar height

For the original five-contact radical M5(u) outside 76176, R(u) divides B_*M5(u). Therefore (1), E(M)<=1+logM, and logB_*>1 imply

\[
h(u)<c_0C_NB_*^2E(B_*)\log B_*\,M_5(u)^2(1+\log M_5(u))^2.
\]

The exact sieve certificate gives B_*<2^109445 and E(B_*)<16; also logB_*<2^17. Thus the leading constant is less than 2^219060. For x>=0, 2exp(x)>1+2x+x^2, so (1+logM)^2<2M. Consequently

\[
\boxed{h(u)<2^{219061}M_5(u)^3.}
\tag{4}
\]

Apply (4) to beta=51X^2+2504, which avoids every excluded scalar contact. The retained scalar divisibility

\[
149^{L_N}M_5(\beta)^3\mid c,\qquad L_N=\lfloor9(2N-1)/4\rfloor+1,
\]

implies

\[
\tau=h(\beta)<2^{219061}149^{-L_N}c.
\tag{5}
\]

## Sum height with arbitrary two-torsion translates

Let K0=Q(sqrt2), d=3-sqrt2, E:y^2=x^3-d^2x, R0=(1+sqrt2,2sqrt2), and P=2R0. Suppose Q_i=[m_i]R0+T_i are four finite points with T_i in E[2](K0), and M0=max(1,|m_i|). Put

\[
\mathcal S=\sum_i x(Q_i),\qquad Z=\mathcal S+4d+1.
\]

All two-torsion abscissae 0,+d,-d are integral. Hence a formal Q_i necessarily has m_i nonzero. Applying multiplication by two kills T_i and proves log(Q_i)=m_i L at each formal place. The formal-logarithm leading coefficient argument of the source therefore extends unchanged: for each subset J, its coefficient is the positive integer sum over j in J of the products of m_k squared for k in J excluding j. Summing the valuations gives loss at most 24logM0+log864.

At either real embedding every finite curve point has x>=-d, and Z>=1. A positive abscissa is at most Z; a negative one has absolute value at most d. The archimedean extra cost is at most h(d)=log7/2. Thus

\[
h(Z)\ge\max_i h(x(Q_i))-24\log M_0-\log864-\tfrac12\log7.
\tag{6}
\]

The source's duplication inequality h(x(2Q))<=4h(x(Q))+log676 implies, by the canonical-height limit, h(x(Q))>=2 hhat(Q)-log676/3. Its bound hhat(P)>=1/2 gives hhat(R0)>=1/8, and canonical height is invariant under torsion translation. In particular, for m_i nonzero,

\[
h(x(Q_i))\ge m_i^2/4-3.
\]

Using the weaker constant 6, the maximum of 24log s-s^2/8 is 12log96-12<43. Equation (6) gives M0^2<8h(Z)+456. If every m_i is zero the same conclusion is immediate from h(Z)>=0.

For the labels n=m1/2, a=m2, t=m3, b=2m4+1, let B=max(1,|n|,|a|,|t|,|b|). Then B<=2M0+1 and (2M0+1)^2<=5M0^2+5, whence

\[
B^2<40h(Z)+2285.
\tag{7}
\]

For the proposed additive charts with U1=t1-t0=13+S0/2 and V2=t2-t1=17+(S0-S1)/2, the exact identity is

\[
Z=-(2+2\rho)t_0+(2+4\rho)t_1-2\rho t_2-13+4\rho.
\]

All coefficients are algebraic integers, and at either real embedding their absolute values sum to less than 32. The standard product height estimate gives h(Z)<=sum_j h(t_j)+log32. Therefore

\[
B^2<40\sum_{j=0}^2h(t_j)+2425.
\tag{8}
\]

The new constants 13 and 17 ensure U1>=7 and V2>=9 since every x(Q_i)>=-d; the three translated contact sets are disjoint.

## Uniform explicit parameter N=6743

Assume the local detector extraction gives M_j^k|J0 separately for all three j, k in {1,3}, whenever J0 is a nonzero integer. Equations (3) and (8), with 2425<484K, give

\[
B^2<121K|J_0|^{1/k}(22+\log|J_0|/(2k))^2.
\tag{9}
\]

For Delta nonzero, use |Delta|<=14B^4 and 121*14^(1/3)<300. Writing s=logB yields

\[
e^{2s/3}<300K(23+2s/3)^2.
\]

The quotient of the left side by the squared factor is increasing for s>=0. At N=6743, L_N=30342 and c>=149^30342. The exact certificate verifies

\[
149^{2\cdot30342}100^6>
300^3 2^{3\cdot109754}(2300+334\cdot30342)^6.
\]

Together with log149<501/100 this is the opposite strict inequality at s=L_Nlog149. Monotonicity excludes Delta nonzero for every N>=6743.

If the reduced numerator J of n-beta is nonzero, |J|<=4Bexp(tau). Equation (9) for k=1 gives

\[
e^s<484K e^\tau(23+(s+\tau)/2)^2.
\]

Taking logarithms and using log(1+x)<=x,

\[
s<\frac{23}{22}\log(256036K)+\frac{12}{11}\tau
<120000+\frac{12}{11}\tau.
\tag{10}
\]

The exact certificate 149^30342>2^219044 and (5) give tau<2^17c for all N>=6743. Also logc>30342*5=151710 and c>600. The affine Lucas normalization of the 229-coordinate chart gives the slightly weaker lower bound (c-6)log(c-3), which suffices:

\[
s\ge(c-6)\log(c-3)>
\frac{99}{100}151709c>150000c.
\]

This contradicts (10), because

\[
150000c>120000+\frac{12}{11}2^{17}c\qquad(c>600).
\]

Therefore n=beta. If n is integral, the old squarefree-51 endpoint applies. If n=m1/2 is merely half-integral, 2beta is integral. For X=u/v in lowest terms, v^2 divides 102; since 102 is squarefree, v=1. Thus X is integral in either case.

All threshold inequalities strengthen as N increases. Completeness still requires the separate chart construction; its scalar size argument only needs N>=3. This note does not claim completeness of an unverified coordinate transplantation.

## Reproducibility

Run `python -B certify_threshold.py` in this directory. The script uses exact rational arithmetic, an elementary sieve, exact contact determinants, and integer comparisons. It does not rely on floating-point numerical evidence.
