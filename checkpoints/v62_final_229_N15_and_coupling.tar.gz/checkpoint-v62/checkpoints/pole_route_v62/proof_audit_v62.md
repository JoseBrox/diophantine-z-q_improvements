# Audit of the finite Möbius coupling obstruction

This review records theorem hypotheses and boundary cases. The independent
algebra computation is `check_independent.py`, which does not import SymPy
or the principal checker. A separate human/agent review remains appropriate
before integration.

## Literal source

The paper treats the six-contact polynomial from the revised v53 conditional
source. It specifies all six tests, both physical weights, the trace, and
the actual fourth- and sixth-power comparison scales. Its fixed test input
is X=1 with the prescribed point A=P, so the trace is exactly 57/4.
The statement is about prescribed-index completeness and about any eventual
restriction whose independent soundness still forces that root index.
It does not silently replace an arbitrary existential A by P.

The derivative 11-variable construction has a different contact polynomial
and is expressly outside this theorem. No 21-, 9-, or new variable record
is implied by the result.

## Finite exhaustive branch argument

A Möbius automorphism of the six finite roots must map a chosen three of
them to an ordered triple of distinct roots. Exhausting the 120 triples
is therefore an exhaustive proof of the finite menu, not a sample.
The principal checker uses rational nullspaces. The independent checker
uses an explicit three-image interpolation formula and exact polynomial
coefficient multiplication. Both return the same twelve maps and multipliers.

The identity forces lambda=0, an explicit contact-guard violation.
For each other branch except the involution, the discriminant obstruction
uses an integer square gap. Its margin is strictly positive at B=3 for
both actual exponents, and N increases as B increases. Thus the exclusion
holds for every permitted shift, including choices of branch depending
on B. No passage from an asymptotic expansion to an exact non-square claim
is made.

## Inert contact and guards

The remaining involution has the unique guarded slope
lambda=-(a+1)/(5a). At the displayed contact roots, a, lambda,
lambda-1, a lambda-1 and 5 lambda+1 are local units. Both physical
weights and both contact denominators have valuation exactly one.
All other auxiliary guards either hold or already disqualify the tuple.

At an inert prime, conjugation fixes the place. The tests f(H) and
conjugate(f(H-P)) cannot both have positive valuation because P reduces
to a nonidentity affine point on the good-reduction curve. All detector
factors have nonpositive valuation, at least one has negative valuation,
and the inverse product trace is divisible by the prime. A zero trace
violates its guard; a nonzero trace gives a negative odd pole valuation.

The prime 76253 is certified by exhaustive trial division. The optional
finite-field certificate proves the exact order 16518755 of the reduction
of P. The proof only needs that reduction to be nonidentity.

## Fixed exceptional sets and choices of class

For e=4, the auxiliary root field is totally ramified of degree four at
17, while 17 splits in Q(sqrt2). For e=6, it is totally ramified of degree
six with residue degree one at 5, while 5 is inert in Q(sqrt2). Therefore
neither root field contains Q(sqrt2). The nontrivial quadratic automorphism
extends to an automorphism of a common Galois closure fixing the chosen
root. Chebotarev gives infinitely many inert primes at which that root
polynomial has a simple residue root. The root translates into a simple
contact of a(B) at 4. All but one lift modulo p^2 have exact valuation one.

This proves that any fixed finite exceptional set can be avoided. It is
not limited to the explicit prime. Fixed rational multipliers add only
finitely many exceptional primes. Arbitrarily varying members of a family
of pole predicates are covered only when all members retain the same
negative-odd-pole exclusion outside the same fixed set. Variable nonunit
square rescalings and local conditions whose exceptional set changes
without bound are not asserted to be covered.

## Strength and limit of conclusion

There are unbounded progressions of disallowed odd coefficient shifts at
the single prescribed input X=1. This disproves the claimed completeness
mechanism for every sufficiently large fixed odd shift. It does not prove
that every fixed shift fails, nor that all finite correspondences or all
possible smaller-variable definitions fail.

## Reference verified

J. S. Milne, *Algebraic Number Theory*, Theorem 8.31, states Chebotarev
for every conjugacy class of a finite Galois extension, with positive
density |C|/|G|. The primary author-hosted source is
https://www.jmilne.org/math/CourseNotes/ANT.pdf, checked 17 November 2026.
The browser reference from this session is `turn374view0`; the parent
should open the source itself before citing that reference in a final answer.
