# Exact alignment of the general ten-contact functions

Status: proved algebraic and local-extraction lemmas; completeness is unproved.
This is a realization criterion with a conditional count of 22 variables for
the general source, not an established defining polynomial and not an abc-based
conditional-source result.

Source: `papers/pole_parameters/reweighted_elliptic_detectors_20261116_v53.tex`
at main `9aa0e31ede062c6bfee592e72468444611642ce5`.

## Source and specialization

Keep the original nine point roles, the scalar rho, the aggregate rational
trace T, the sixteen comparison tests, the six scalar tests, and every
point/difference/quotient guard. In the notation of the source, set

\[
 a_0=1,\quad a_1=1+\rho T^2,\quad t_j=a_j\lambda,
 \quad\delta_j=t_j+j+1,
\]

\[
 \Theta=\{0,-1/2,-1,1/2399,-32/407\},\qquad
 \Theta_j=(4j+2+\Theta)\cup(4j+4+\Theta),
\]

\[
 R_j=\frac{\prod_{\theta\in\Theta_j}(t_j-\theta)}{\delta_j^{10}},
 \qquad u_j=\rho R_j,\qquad w_j=\frac{u_j}{(1+u_j)^2}.
\]

Impose the rational specialization

\[
                         \lambda=\frac4{\rho T^2},
\]

with the added guard `T != 0`. Then `a_1 lambda=lambda+4` and the
two degree-ten contact numerators agree exactly. Consequently

\[
            R_1=R_0\left(\frac{\lambda+1}{\lambda+6}\right)^{10}.
\]

Let S contain all primes dividing the nonzero numerators and denominators
of the contact constants, their pairwise differences, and their differences
from -1 and -6, together with 2,3 and the original exceptional set. This
is fixed independently of rho, T, and all point indices.

## Local alignment lemma

For a prime `p` outside S:

1. If `v_p(rho)` is odd, then `v_p(lambda)=-v_p(rho)-2v_p(T)` is
   odd and nonzero. The balanced contact function `R_0` is a unit:
   for a positive argument valuation every numerator and denominator
   factor is a unit; for a negative argument valuation their ten
   valuations cancel. Thus the first detector alone supplies the scalar
   extraction inequalities of Proposition 2.3 of the source.
2. Every odd valuation of either `R_j` is positive. At a finite pole the
   valuation is a multiple of ten, and at an argument of negative
   valuation the function is a unit. Therefore an odd valuation must be
   a contact valuation.
3. At any contact, both `lambda+1` and `lambda+6` are units. The displayed
   identity therefore gives `v_p(R_0)=v_p(R_1)>0`. In particular a positive
   odd contact of either function is a positive odd contact of the first,
   with both normalizers units.
4. At an odd contact, if `v_p(rho)` is odd, the first detector supplies
   the source scalar alternative `v_p(c)>=3`. If it is even, then
   `v_p(u_0)` is odd, and the physical weight has positive valuation
   `abs(v_p(u_0))`. The source trace argument at the first detector gives
   the same positive valuations of all sixteen comparison tests. This
   is exactly the mixed-contact alternative for both `R_j`.

These proofs use only valuation identities and the source's proved local
trace implication. The contact and scalar height arguments can therefore
use the first detector's local conclusions at both contact functions.

## Realization criterion and census

Assume the original arithmetic premises, and assume additionally that every
integer input has a tuple of the nine retained points satisfying the new
specialization and all guards, for which the single actual input

\[
 d_0=7b_0=\frac{28u_0}{(1+u_0)^2V_0^2}
\]

has a prepared intrinsic-pole witness avoiding the whole-algebra guards.
Then the retained source proof, with the local alignment lemma above, gives
an integer definition with the following free-coordinate count:

| Role | Count |
|---|---:|
| Input | 1 |
| Nine elliptic point coordinates over the quadratic field | 18 |
| One intrinsic pole block | 2 |
| Finite-algebra separator | 1 |
| Total | 22 |

The slope is the displayed rational function, not a free coordinate. The
second pole block is omitted. Finite algebraic square roots are not free
coordinates, as in the source's determinant construction. The added
nonzero condition on T is included in the guard product and does not add
a free coordinate.

## Unresolved realization and scope

The additional realization hypothesis is not proved. The original ordered
prime-pattern completeness proof chooses the slope after fixing the root
points and trace. That step is unavailable here because the slope is fixed
by rho and T. Neither a local-approximation statement nor the generic
intrinsic-pole converse repairs this missing arithmetic selection. In
particular, one must arrange the actual odd contact primes and reduction
conditions, real preparation, all local square classes, and every
whole-algebra guard simultaneously. No claim that any one of these issues
is the only gap is made.

Eliminating one additional intrinsic-pole coordinate after proving this
realization would target 21 variables, but that is a second unresolved
condition. The six-contact conditional source has a different scale and
contact polynomial, so this alignment yields no 10- or 9-variable
conditional result.

## Related completed obstruction

The separate polished manuscript
`negative_results/papers/pole_parameters/six_contact_mobius_obstruction_20261117_v62.tex`
classifies all 12 rational Möbius symmetries of the six-contact polynomial
and rules out eventual prescribed-index completeness for their direct
coupling to the retained fourth- and sixth-power scales. Its computation
is in `negative_results/computation/six_contact_mobius_v62/`.

This obstruction concerns that conditional scale and does not refute the
general ten-contact alignment criterion above.
