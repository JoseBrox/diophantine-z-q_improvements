# Reflected-contact center refinements

## Status

These are arithmetic and contact-support refinements of the frozen N=19 argument. They require the matching contact coefficients in the 229-coordinate row table and the corresponding completeness chart; those exact row checks are assigned separately. The original files `../finite_cutoff_proof.md` and `../certify_finite_cutoff.py` remain unchanged.

The bounded search examined all 5036 admissible reduced rational centers with absolute value at most2 and denominator at most64. It minimizes the product of the exceptional primes, not the final polynomial coefficient height. In this search, center3/11 is best. This center is already mentioned as a sibling contact system in the upstream manuscript; no novelty claim for the center itself is made.

## General center

For c=a/q in lowest terms with q>0, use

\[
\Theta_c=\Theta\cup(c-\Theta),\qquad
\Theta=\{0,-1/2,-1,1/2399,-32/407\}.
\]

Require all ten contacts to be distinct. Let Gamma_c consist of the fixed set S10 together with the prime support of every contact denominator and every pairwise difference. This also covers the denominators and numerators of theta-c/2, since 2theta-c is a cross-contact difference and2 is already exceptional.

The two height maps are u_+=2+1/t and u_-=2+1/(c-t). Their inverse height constants are bounded by

\[
H_c=\max(3,|a|+|2a+q|,3q).
\]

Indeed the second inverse map is t=(a u_- -2a-q)/(q u_--2q), and its integral matrix is primitive. With J_c=product of Gamma_c and M the odd contact radical outside Gamma_c, the same joint argument gives

\[
h(t)\le\log H_c+C_cM\sqrt{E(M)}
(\log J_c+\tfrac12\log M),
\quad C_c=c_0C_NJ_c^2E(J_c).
\]

The displayed product is multiplication by the final parenthesis. All local scalar arguments are unchanged. The widened detector proof uses the changed midpoint c/2 in place of1, and otherwise is identical: every consumed contact is simple modulo p, the midpoint is a unit distance away, and v_p(q) is the negative odd contact depth. The favorable p=409 case remains available.

The completeness construction can continue selecting large primes. The new paired function is

\[
R_c(t)=\prod_{\theta\in\Theta}
\left(1-\frac{(\theta-c/2)^2}{(t-c/2)^2}\right).
\]

At large real t it approaches1 from below, and at the prepared finite places t is chosen with sufficiently negative valuation. Thus the real pole interval and local square preparation have the same limits. Every candidate tabulated below has contact span less than7, so the shifts U1>=7 and V2>=9 preserve disjointness of all thirty translated contacts. The generalized prime-pattern application must be written with these actual rational contacts, not silently identified with the old center2 polynomial.

## Certified candidates

| Center c | Extra primes beyond S10 | J_c bit length | Sufficient N | L_N | Bound C_c | Coarse input bound K | H_c |
|---|---|---:|---:|---:|---:|---:|---:|
| 3/11 | 79,89,647,3593 |75|15|66|2^300|2^304|33|
| -1/8 |23,29,59,79,83,151,211,373|93|17|75|2^335|2^340|24|
|1|47,79,109,157,257,439,1439,2221|106|18|79|2^361|2^366|4|
|-4/7|19,31,59,83,97,127,719,8123|99|18|79|2^347|2^352|21|
|2|47,67,109,179,257,439,2099,2029147|116|19|84|2^381|2^386|7|

The script `certify_centers.py` certifies these numerical thresholds by exact rational logarithm enclosures with proved positive-series tails. For each candidate, the preceding N fails this particular sufficient numerical comparison. That is not a lower bound on the true defining threshold.

## Center 3/11 and N=15

For this center,

\[
J_c=30366775457346956958330<2^{75},\quad H_c=33,
\quad C_c<2^{300}.
\]

The product of (1+1/p) over primes at most1000 outside Gamma_c is less than21/10. Hence

\[
E(M)<\frac{21}{10}M^{1/6006}.
\]

After absorbing the additive height constants and using |Delta|<=14B^4, the 229-coordinate sum-height consumer gives

\[
e^{\frac23(1-1/6006)s}
<500\cdot2^{300}(53+2s/3),\qquad s=\log B.
\]

For N=15, L_N=66. At s=66log149, the logarithm of the left side is greater than

\[
220\frac{6005}{6006}>219.963,
\]

whereas the logarithm of the right side is less than

\[
\frac{25}{4}+300\frac{173287}{250000}+\frac{45}{8}
=219.8194.
\]

Here 5<log149<501/100, log500<25/4, log2<173287/250000, and log274<45/8. These can all be certified by finite exponential sums. Monotonicity gives the Delta contradiction for every N>=15.

The scalar estimate remains h(beta)<2^238 M_S(beta)^3, so h(beta)<c/2 because149^66>2^239. The coarse contact bound is

\[
h(t)\le2^{304}M(22+\tfrac12\log M)^2.
\]

The input consumer then gives logB<240+c, whereas the affine Lucas bound is greater than320c for c>=149^66. This proves the same soundness endpoint for every N>=15. The remaining requirement is the exact changed-contact row/completeness verification.

## Quadratic contact circuit

For c=3/11, store r=(22t-3)^2. The five paired factors are

\[
r-9,\quad r-196,\quad r-625,\quad
r-(7175/2399)^2,\quad r-(175/37)^2.
\]

The common factor22^10 cancels between the numerator and denominator of R_c(t), so no new coordinate is required by this normalization itself. In the existing homogeneous stored variables, the square row becomes

\[
(22t_{\rm stored}-3q_0)^2-q_0r_{\rm stored}=0.
\]

For c=-1/8, use r=(16t+1)^2 and paired constants

\[
1,\quad49,\quad225,\quad(2415/2399)^2,\quad(105/407)^2.
\]

These describe the intended contact replacement; they do not by themselves establish the support, coefficient height, or complete count of the modified polynomial. The coefficient audit should minimize the final maximum of the fixed coefficient height and the parameter-dependent coefficient height, as required by the project's priority order.
