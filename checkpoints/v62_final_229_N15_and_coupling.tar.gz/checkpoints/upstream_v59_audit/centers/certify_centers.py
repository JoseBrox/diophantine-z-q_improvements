#!/usr/bin/env python3
"""Exact certificates for several reflected-contact centers.

Numerical sufficiency and finite contact support are certified here.
Polynomial coordinate tables and global completeness maps are separate.
"""
from fractions import Fraction as F
from math import isqrt, prod

S = {2, 3, 5, 7, 11, 13, 17, 37, 41, 2399}
theta = [F(0), F(-1, 2), F(-1), F(1, 2399), F(-32, 407)]
CN = 2**68 * 3**16 * 5**16 * 7**4
c0 = F(74712001, 1000000)


def log_unit_interval(x, terms=28):
    assert 1 <= x <= 2
    z = (x - 1) / (x + 1)
    z2 = z * z
    power = z
    total = F(0)
    for j in range(terms):
        total += 2 * power / (2 * j + 1)
        power *= z2
    tail = 2 * power / ((2 * terms + 1) * (1 - z2))
    return total, total + tail


LN2 = log_unit_interval(F(2))


def log_interval(x):
    x = F(x)
    assert x > 0
    k = x.numerator.bit_length() - x.denominator.bit_length()
    scale = F(2**k) if k >= 0 else F(1, 2**(-k))
    y = x / scale
    if y < 1:
        k -= 1
        y *= 2
    elif y >= 2:
        k += 1
        y /= 2
    lo, hi = log_unit_interval(y)
    if k >= 0:
        return lo + k * LN2[0], hi + k * LN2[1]
    return lo + k * LN2[1], hi + k * LN2[0]


def prime(p):
    return p >= 2 and all(p % d for d in range(2, isqrt(p) + 1))


small_primes = [p for p in range(2, 1001) if prime(p)]
assert len(small_primes) == 168


def support_in(n, gamma):
    n = abs(n)
    assert n
    used = set()
    for p in gamma:
        if n % p == 0:
            used.add(p)
            while n % p == 0:
                n //= p
    assert n == 1
    return used


def ceiling_binary(x):
    x = F(x)
    e = x.numerator.bit_length() - x.denominator.bit_length()
    while x >= 2**e:
        e += 1
    while x < 2**(e - 1):
        e -= 1
    return e


cases = [
    (F(3, 11), 15, {79, 89, 647, 3593}),
    (F(-1, 8), 17, {23, 29, 59, 79, 83, 151, 211, 373}),
    (F(1), 18, {47, 79, 109, 157, 257, 439, 1439, 2221}),
    (F(-4, 7), 18, {19, 31, 59, 83, 97, 127, 719, 8123}),
    (F(2), 19, {47, 67, 109, 179, 257, 439, 2099, 2029147}),
]

for center, target_N, extra in cases:
    gamma = S | extra
    assert all(prime(p) for p in gamma)
    contacts = theta + [center - t for t in theta]
    assert len(set(contacts)) == 10 and center / 2 not in contacts
    assert max(contacts) - min(contacts) < 7
    used = set()
    for t in contacts:
        used |= support_in(t.denominator, gamma)
        used |= support_in((t - center / 2).numerator, gamma)
        used |= support_in((t - center / 2).denominator, gamma)
    for i, t in enumerate(contacts):
        for u in contacts[i + 1 :]:
            used |= support_in((t - u).numerator, gamma)
            used |= support_in((t - u).denominator, gamma)
    assert used - S == extra
    J = prod(gamma)
    C = c0 * CN * J * prod(p + 1 for p in gamma)
    E_low = prod(F(p + 1, p) for p in small_primes if p not in gamma)
    H = max(3, abs(center.numerator) + abs(2 * center.numerator + center.denominator), 3 * center.denominator)
    assert C > 2425 + 120 * log_interval(H)[1]

    L = 9 * (2 * target_N - 1) // 4 + 1
    log149 = log_interval(149)
    log14 = log_interval(14)
    logJ = log_interval(J)
    logC = log_interval(C)
    logElow = log_interval(E_low)
    b_lo, b_hi = L * log149[0], L * log149[1]
    lam = F(2, 3) * (1 - F(1, 6006))
    alpha = F(1, 3) + F(1, 36036)
    shape_hi = logJ[1] + log14[1] / 6 + 2 * b_hi / 3
    margin_lo = lam * b_lo - log_interval(121)[1] - logC[1] - logElow[1] / 2 - alpha * log14[1] - log_interval(shape_hi)[1]
    assert margin_lo > 0

    # The previous N does not pass this precise sufficient comparison.
    old_L = 9 * (2 * (target_N - 1) - 1) // 4 + 1
    old_b_lo, old_b_hi = old_L * log149[0], old_L * log149[1]
    old_shape_lo = logJ[0] + log14[0] / 6 + 2 * old_b_lo / 3
    old_margin_hi = lam * old_b_hi - log_interval(121)[0] - logC[0] - logElow[0] / 2 - alpha * log14[0] - log_interval(old_shape_lo)[0]
    assert old_margin_hi < 0

    # Coarse bound used solely for the input/Lucas comparison.
    m = J.bit_length()
    e = 0
    while 1 + F(7 * m, 10) >= 22 * 2**e:
        e += 1
    K_exp = 150 + 2 * m + 2 * e
    assert log_interval(H)[1] < 2 ** (K_exp - 1) * 484
    input_const_hi = F(23, 22) * (K_exp + 18) * LN2[1]
    assert 149**L > 2**239 and 149**L > 600
    assert F(99, 100) * (5 * L - 1) > input_const_hi / 600 + F(6, 11)

    print(f"PASS center={center}, N>={target_N}, L={L}, J={J}, C<2^{ceiling_binary(C)}, K=2^{K_exp}, H={H}")
    print("  Certified positive Delta margin; previous N fails this particular sufficient comparison.")

print("Scope: no claim of globally optimal center or minimal defining N; row/completeness verification is separate.")
