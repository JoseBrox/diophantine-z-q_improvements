# Completeness under reflection about 3/22

Use the ten contacts Theta union (3/11-Theta), where Theta is {0,-1/2,-1,1/2399,-32/407}, and midpoint m=3/22. Retain the scalar construction and all elliptic/root choices from the 229-coordinate completeness proof. Only the contact parameters below change.

Every contact lies in [-1,14/11], so their span is25/11. The actual additive shifts U1>=7, V2>=9, U2=U1+V2 therefore give thirty distinct translated contacts. Take D0 so that D0^2 clears the denominators of all shifts, contacts, midpoint, and their differences. The coefficient corresponding to the contact0 in the first block is still zero. The prime-pattern theorem thus has the same required zero coefficient and distinct remaining rational inputs after clearing.

The finite preparation set includes all contact denominators, differences, and midpoint distances. Their prime support outside the existing S10 is {79,89,647,3593}; all of these primes are below the original cutoff76176. The construction may retain every original small-prime preparation, together with the input-dependent finite guard set. Thus no strengthened prime-selection theorem is required.

Choose the same sufficiently divisible denominator w, replacing each old difference U_j-1 by U_j-m in its finite preparation inequalities. This makes t_j-m have sufficiently negative valuation at every prepared prime. The new contact function is

\[
R(t)=\prod_{\theta\in\Theta}
\left(1-\frac{(\theta-m)^2}{(t-m)^2}\right).
\]

Consequently R is arbitrarily close to1 at those places, q=1/R-1 has the required positive valuation, and every detector factor is as close to1 as required. The trace tends to2, so the existing gamma=408/409 square preparation at2,3,17 is unchanged. At the real places, taking the slope sufficiently large gives0<R<1, q>0, and R tends to1. With the already bounded real tests, the pole input still tends to gamma^2/4 in the allowed interval.

The prime pattern supplies thirty distinct large primes

\[
p_{j,\theta}=u+D_0^2(U_j-\theta)w^2.
\]

All can still be chosen above76176 and away from the finite preparation set. At a selected prime for one contact, t_j-theta has valuation1, every other contact factor is a unit, and t_j-m is a unit because theta-m is a unit there. Hence R has valuation1 and q has valuation-1. The existing elliptic residue-depth argument and trace calculation therefore produce pole-input valuation1. At other primes outside the prepared set, the denominator of R is a tenth power:

\[
R(t_j)=
\frac{\prod_{\theta\in\Theta\cup(3/11-\Theta)}p_{j,\theta}}
{(u+D_0^2(U_j-m)w^2)^{10}}.
\]

Thus the remaining valuations have the same even parity required by the pole construction. The selected primes for different blocks remain distinct, and no assertion of radical coprimality for arbitrary source solutions is needed.

The existing CRT step, real recurrence of the reference point, guard avoidance, and four independent pole realizations now apply to these actual inputs. The reference/root/scalar equations are unchanged. The exact contact identity with r=(22t-3)^2 is

\[
\prod_{a\in\{3,14,25,7175/2399,175/37\}}(r-a^2)
=22^{10}\prod_{\theta\in\Theta}(t-\theta)(t-(3/11-\theta)).
\]

The factor22^10 cancels against (22t-3)^10. Therefore the verified replacement contact rows have the intended physical R and q, and their existing inverse equations give the same nonzero guards. This changes no coordinate count and adds no constraint. The scalar size preparation still requires only N>=3, so the soundness choice N=15 is admitted.
