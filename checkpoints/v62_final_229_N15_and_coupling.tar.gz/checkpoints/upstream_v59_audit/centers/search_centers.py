#!/usr/bin/env python3
"""Bounded exploratory search; no polynomial-row change is asserted."""
import json
from fractions import Fraction as F
from functools import lru_cache
from math import log2, prod
from pathlib import Path
from sympy import factorint

S = {2, 3, 5, 7, 11, 13, 17, 37, 41, 2399}
theta = [F(0), F(-1, 2), F(-1), F(1, 2399), F(-32, 407)]


@lru_cache(maxsize=None)
def support(n):
    return frozenset(factorint(abs(n)))


results = []
for den in range(1, 65):
    for num in range(-2 * den, 2 * den + 1):
        center = F(num, den)
        if center.denominator != den:
            continue
        contacts = theta + [center - t for t in theta]
        if len(set(contacts)) != 10:
            continue
        gamma = set(S)
        for t in contacts:
            gamma.update(support(t.denominator))
        for i, t in enumerate(contacts):
            for u in contacts[i + 1 :]:
                gamma.update(support((t - u).numerator))
        radical = prod(gamma)
        results.append((radical, center, sorted(gamma - S)))

results.sort()
rows = [{"center": str(c), "exceptional_product": str(j), "product_bits_approx": log2(j), "extra_primes": p}
        for j, c, p in results[:30]]
output = Path(__file__).with_name("center_search_results.json")
output.write_text(json.dumps({"domain": "reduced |center|<=2, denominator<=64", "tested": len(results), "best": rows}, indent=2) + "\n")
print("Tested", len(results), "admissible reduced centers; saved", output)
for row in rows[:10]:
    print(row)
