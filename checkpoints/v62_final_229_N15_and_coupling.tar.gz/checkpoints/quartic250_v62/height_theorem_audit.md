# Independent audit: effective heights with torsion translates

The theorem in `papers/effective_sums/effective_torsion_sums_20261117_v62.tex`
has been independently checked on the full stated finite point domain.
The sharper ramification allowance below is valid. This audit proves no
Diophantine definability assertion over a new number field.

Let K be totally real of degree k, let d be a totally positive algebraic
integer, and let P have infinite order on E: y²=x³−d²x. For r≥1 let
Qi=[ni]P+Ti be finite, with integer ni and arbitrary K-rational torsion Ti.
Set M=max(1,|ni|) and Z=Σ x(Qi)+rd+1. Then

```math
h(Z)\ge\max_i h(x(Q_i))-(r-1)2^{r-1}\log M
-\sum_{j=1}^r\binom{r-1}{j-1}\log j-h(d)-R_K,
```

with the strengthened constant

```math
R_K=\frac{2}{k}\sum_{\mathfrak p\mid p,\ p\ne2}
 f_{\mathfrak p}\left\lfloor\frac{e_{\mathfrak p}-1}{2}\right\rfloor\log p
\le\frac1k\log|\operatorname{disc}K|.
```

## Decisive local estimate

For z=−x/y and D=d²,

```math
x(z)=z^{-2}+Dz^2-D^2z^6+2D^3z^{10}-\cdots,
\qquad
\ell(z)=\sum_{j\ge0}\frac{(-1)^j\binom{2j}{j}D^j}{4j+1}z^{4j+1}.
```

The first follows from x²−z⁻²x−D=0; differentiating gives
dx/(2y)=dz/√(1+4Dz⁴), proving the second. The logarithm expansion
is not asserted integral at every odd prime.

At an odd prime with ramification e, put a=v(z). If a≥ceil(e/2),
then every nonconstant term of ℓ(z)/z has valuation at least 2a.
Indeed vp(4j+1)≤2j−1: 3^(2j)>4j+1 for j≥1, and p≥3.
Thus 4ja−e vp(4j+1)≥4ja−2a(2j−1)=2a.
At p=2 all denominators 4j+1 are units, so every formal point
(a≥1) has the same estimate. In both cases the logarithm is
isometric and x(z)−ℓ(z)⁻² is integral.

A finite point outside this deep subgroup has denominator depth
at most b=2(ceil(e/2)−1)=2 floor((e−1)/2) at odd primes, and
zero at p=2. This covers shallow torsion points without claiming
that they are integral.

## Torsion and cancellation

The deep subgroup is open. Multiplying P by a suitable integer
places it there, defining a nonzero common local logarithm L.
For every deep Qi, multiplication by a common multiple of that
integer and the order of Ti gives ℓ(Qi)=ni L. Thus a finite deep
point has ni≠0, even when arbitrary torsion translates are allowed.

For the set J of deep indices, the integer
CJ=Σ[j∈J] Π[a∈J\{j}] na² is strictly positive. For a fixed target
i∈J, the principal part of Z relative to x(Qi) has multiplier
CJ/Π[j∈J\{i}] nj². The remaining abscissas and the integral shift
have valuation at least −b. If the principal part is deeper than
b, it determines the valuation of Z; otherwise the whole local
height of x(Qi) is at most v(CJ)+b. The loss is therefore at most
v(CJ)+b in both cases. When i is not deep, its whole local loss
is at most b and no CJ is charged.

Only subsets containing the fixed target i occur. Since
CJ≤|J| M^(2(|J|−1)), their global cost is exactly bounded by
(r−1)2^(r−1) log M + Σ[j] binom(r−1,j−1) log j. Negative,
zero and repeated indices do not affect positivity of CJ.

The local-height normalization is f log p/k for v having value
group Z. The different exponent is at least e−1 and
2 floor((e−1)/2)≤e−1; hence the discriminant bound above.
In particular all primes of ramification index one or two contribute
zero to R_K, not only the dyadic primes.

## Archimedean estimate and four-point numerical corollary

At every real embedding x(Qi)≥−d, hence Z≥1. A positive summand
is at most Z and a negative summand has absolute value at most d.
The total archimedean loss is therefore at most h(d), since d is
integral. This completes the height proof.

For K=Q(√2), d=3−√2, R0=(1+√2,2√2), and the source inputs
ĥ(2R0)≥1/2 and h(x(2Q))≤4h(x(Q))+log676, the manuscript's
four-point deduction is correct: h(x([m]R0+T))≥m²/4−3 for
nonzero m, then M²<8h(Z)+456 and B²<40h(Z)+2285. Here
A4=24, B4=log864 and h(d)=½log7. The weaker constant six in
the manuscript is harmless and yields the displayed strict
inequality using 24logM−M²/8≤12log96−12<43.
